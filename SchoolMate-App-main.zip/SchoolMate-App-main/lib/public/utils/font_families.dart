class RedHatDisplay {
  static const bold = 'RedHatDisplay-Bold';
  static const light = 'RedHatDisplay-Light';
  static const medium = 'RedHatDisplay-Medium';
  static const regular = 'RedHatDisplay-Regular';
}

class SFPro {
  static const bold = 'SFProDisplay-Bold';
  static const medium = 'SFProDisplay-Medium';
  static const regular = 'SFProDisplay-Regular';
}