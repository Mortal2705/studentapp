class SubjectInf {

  static String Subject_uId='';
  static List task= [];

}