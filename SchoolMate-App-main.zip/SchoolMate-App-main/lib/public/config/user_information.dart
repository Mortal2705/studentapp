class UserInformation {
  static String User_uId = 'PAst7TbWWXcxEm5kf4SZJEHtoBZ2';
  static String teacherverifycode = '0597';
  static String parentverifycode = '0597';
  static String email = 'StudentFML@gmail.com';
  static var classroom;
  static var classid = 'Obvy45pTfBnKgtxViAfB';
  static var grade = 2;
  static var grade_average = 0.8;
  static String first_name = 'Yassin';
  static String last_name = 'Almhdi';
  static String? Token;
  static var fees = '1000';
  static var phone = '0966666';
  static var date_start;
  static var date_left;
  static var Subjects = [];
  static var parentphone = '0999';
  static var urlAvatr =
      'https://firebasestorage.googleapis.com/v0/b/school-management-system-6b1c2.appspot.com/o/profilePics%2FPAst7TbWWXcxEm5kf4SZJEHtoBZ2?alt=media&token=ac83a38c-026d-4a4d-a3c8-1d8871e028a3';
  static var clasname = 'A';
  static var fullfees = '900';
  static var fullname = 'Yassin Almhdi';
  static var about;
  static bool uParent = false;
}
