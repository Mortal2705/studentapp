class TeacherSubjects {
  static var subjectsList = [];
}
