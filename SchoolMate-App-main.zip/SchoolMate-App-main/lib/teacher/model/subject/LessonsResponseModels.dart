class LessonsResponseModel {
  final numberOflesson;
  final lessons;
  final numberOfTakenLessons;
  LessonsResponseModel({
    this.numberOflesson,
    this.lessons,
    this.numberOfTakenLessons,
  });
}
