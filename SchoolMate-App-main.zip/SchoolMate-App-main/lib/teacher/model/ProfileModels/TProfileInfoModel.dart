class TProfileInfoModel {
  var fname;
  var lname;
  var subjects;
  var email;
  var about;
  var photoUrl;
  TProfileInfoModel({
    this.about,
    this.email,
    this.fname,
    this.lname,
    this.subjects,
    this.photoUrl,
  });
}
