class SProfileInfoModel {
  var fname;
  var lname;
  var avrg;
  var url;
  var phone;
  var paretnPhone;
  var grade;
  var classroom;
  var classId;
  var uid;
  SProfileInfoModel({
    this.avrg,
    this.fname,
    this.lname,
    this.url,
    this.phone,
    this.paretnPhone,
    this.grade,
    this.classroom,
    this.classId,
    this.uid,
  });
}
