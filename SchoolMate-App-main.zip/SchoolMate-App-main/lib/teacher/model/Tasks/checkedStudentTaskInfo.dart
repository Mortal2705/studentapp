class CheckedStudentTaskInfo {
  var name;
  var uploadeDate;
  var photoUrl;
  var id;
  var taskUrl;
  var task_id;
  var student_id;
  var class_id;
  var mark;
  CheckedStudentTaskInfo({
    this.name,
    this.photoUrl,
    this.uploadeDate,
    this.mark,
    this.id,
    this.taskUrl,
    this.class_id,
    this.student_id,
    this.task_id,
  });
}
