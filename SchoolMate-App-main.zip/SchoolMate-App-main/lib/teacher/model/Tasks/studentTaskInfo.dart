class StudentTaskInfoModel {
  var name;
  var uploadeDate;
  var photoUrl;
  var id;
  var taskUrl;
  var task_id;
  var student_id;
  var class_id;
  StudentTaskInfoModel({
    this.name,
    this.photoUrl,
    this.uploadeDate,
    this.id,
    this.taskUrl,
    this.class_id,
    this.student_id,
    this.task_id,
  });
}
