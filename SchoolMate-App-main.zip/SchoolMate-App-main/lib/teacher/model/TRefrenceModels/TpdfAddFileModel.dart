class TpdfAddFileModel {
  var grade;
  var name;
  var subjectName;
  var subject_id;
  var type;
  var file;
  TpdfAddFileModel({
    this.grade,
    this.name,
    this.subjectName,
    this.subject_id,
    this.type,
    this.file,
  });
}
