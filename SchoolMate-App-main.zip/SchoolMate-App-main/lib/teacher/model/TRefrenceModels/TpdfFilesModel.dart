class TpdfFilesModel {
  var file_name;
  var subject_name;
  var file_id;
  var subject_id;
  var url;
  TpdfFilesModel({
    this.file_name,
    this.subject_name,
    this.file_id,
    this.subject_id,
    this.url,
  });
}
