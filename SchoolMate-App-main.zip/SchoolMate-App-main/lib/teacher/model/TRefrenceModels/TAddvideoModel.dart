class AddVideoModel {
  var grade;
  var name;
  var subjectName;
  var subject_id;
  var type;
  var url;
  AddVideoModel({
    this.grade,
    this.name,
    this.subjectName,
    this.subject_id,
    this.type,
    this.url,
  });
}
