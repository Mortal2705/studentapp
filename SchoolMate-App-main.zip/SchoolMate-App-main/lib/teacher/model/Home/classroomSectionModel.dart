class ClassRoomSection {
  final section;
  final classRoomId;
  ClassRoomSection({this.section, this.classRoomId});
}
