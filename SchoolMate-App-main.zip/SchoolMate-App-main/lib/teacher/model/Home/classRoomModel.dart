class ClassRoomModel {
  final section;
  final grade;
  final numberOfstudents;
  final classroomID;

  ClassRoomModel(
      {this.section, this.grade, this.numberOfstudents, this.classroomID});
}
