// TODO to change current user use the required data and hot restart

// Christine
// String myId = '5oRHGIPx1Z0wJa3z3Y9S';
// String myUsername = 'Christine Wallace';
// String myUrlAvatar = 'https://i.imgur.com/GXoYikT.png';

// Napoleon
import 'package:school_management_system/public/config/user_information.dart';

String myId = UserInformation.User_uId;
String myUsername = 'Barack Obama';
String myUrlAvatar = 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/8d/President_Barack_Obama.jpg/480px-President_Barack_Obama.jpg';
