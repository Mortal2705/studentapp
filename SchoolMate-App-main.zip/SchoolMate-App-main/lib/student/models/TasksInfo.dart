class TasksInfo {
  var subjectName;
  var taskName;
  var uploadDate;
  var deadLine;
  var url;
  var task_id;

  TasksInfo({
    this.subjectName,
    this.taskName,
    this.uploadDate,
    this.deadLine,
  });
}
