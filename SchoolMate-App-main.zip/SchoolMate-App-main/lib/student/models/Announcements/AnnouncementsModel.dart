class AnnouncementsModesl {
  final title;
  final date;
  final content;

  AnnouncementsModesl({this.title, this.date, this.content});
}
