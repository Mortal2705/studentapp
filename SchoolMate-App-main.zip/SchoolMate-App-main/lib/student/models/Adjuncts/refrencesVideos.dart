class RefrencesVideos {
  var url;
  var videoName;
  var subject;
  var teacher_name;
  var subject_id;
  var subject_name;

  RefrencesVideos(
      {this.url,
      this.videoName,
      this.subject,
      this.teacher_name,
      this.subject_id,
      this.subject_name});
}
