class QuizzModel {
  var quiz_id;
  var subject_name;
  var question;
  var def;
  var name;
  QuizzModel(
      {this.def, this.question, this.quiz_id, this.subject_name, this.name});
}
