import 'package:flutter/material.dart';

class ChipsData {
  String? label;

  ChipsData({
    this.label,
  });
}
