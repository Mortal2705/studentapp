class FiltredData {
  final grade;
  final subject;
  FiltredData({this.grade, this.subject});
}
