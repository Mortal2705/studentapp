class GradeCircle {
  final grade;
  GradeCircle({this.grade});
}
