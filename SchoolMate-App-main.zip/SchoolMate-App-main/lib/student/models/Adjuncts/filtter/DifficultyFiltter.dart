class DifficultyFiltter {
  final difficulty;
  DifficultyFiltter({this.difficulty});
}
