class Program {
  String? id;
  String? type;
  String? url;
  String? classroom;
  var date;


  Program({
     this.id, 
     this.type,
     this.url,
     this.classroom,
     this.date,
    });
}


