class SubjectModel {
  final name;
  final id;
  final teacherName;
  final lessonsNumber;
  final takenLessons;
  SubjectModel({
    this.id,
    this.name,
    this.teacherName,
    this.lessonsNumber,
    this.takenLessons,
  });
}
