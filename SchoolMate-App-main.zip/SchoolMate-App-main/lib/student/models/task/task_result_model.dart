class TaskResultModel {
  var classroom_id;
  var student_id;
  var task_id;
  var url;
  TaskResultModel({this.classroom_id, this.student_id, this.task_id, this.url});
}
