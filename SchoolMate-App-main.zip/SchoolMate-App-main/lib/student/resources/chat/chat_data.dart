
import 'package:school_management_system/public/config/user_information.dart';

String myId = UserInformation.User_uId;
String myUsername = UserInformation.first_name;
String? myUrlAvatar = UserInformation.urlAvatr;
