/*Map<String, dynamic> toJSON() {
  return <String, dynamic>{
    'text': text,
    'selectionBase': selection.baseOffset,
    'selectionExtent': selection.extentOffset,
    'selectionAffinity': selection.affinity.toString(),
    'selectionIsDirectional': selection.isDirectional,
    'composingBase': composing.start,
    'composingExtent': composing.end,
  };
}*/

