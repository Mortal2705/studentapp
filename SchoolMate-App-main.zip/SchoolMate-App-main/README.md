# SchoolMate-App
![student mockup_112716](https://github.com/Yassin522/SchoolMate-App/assets/88105077/285ac72b-da7c-43c2-b980-3dbef4c23b75)

![teacher mockup_014955](https://github.com/Yassin522/SchoolMate-App/assets/88105077/0b2c3ae4-efe6-4741-995b-afb67101d482)
